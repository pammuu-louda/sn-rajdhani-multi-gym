# Test Credentials - Use These! 🔑

## THE PROBLEM

The errors you're seeing mean:
1. **"Invalid login credentials"** = The email/password don't match any account
2. **"Email already registered"** = An account exists, but you're using wrong password to login
3. **401 errors** = No valid session token (because login failed)

---

## THE SOLUTION

**Use THESE EXACT credentials - copy and paste them!**

### Test Owner Account ✅

```
Email:    owner@test.gym
Password: TestOwner2026
```

**How to use:**
1. Go to `/signup` page
2. Select "Owner" role
3. Copy-paste the email above
4. Copy-paste the password above
5. Click "Sign Up"
6. Then go to `/login?role=owner`
7. Use THE SAME email and password
8. You should login successfully!

---

### Test Member Account ✅

```
Email:    member@test.gym
Password: TestMember2026
Name:     Alex Johnson
DOB:      1995-03-15
```

**How to use:**
1. Go to `/signup` page
2. Select "Member" role
3. Copy-paste the credentials above
4. Click "Sign Up"
5. Then go to `/login?role=member`
6. Use THE SAME email and password
7. Complete onboarding
8. You should reach home screen!

---

## IMPORTANT RULES

### ✅ DO:
- Copy-paste the credentials EXACTLY
- Use lowercase for emails
- Remember passwords are case-sensitive
- Use the same credentials for signup AND login
- Check console logs for any errors

### ❌ DON'T:
- Type credentials manually (typos cause issues)
- Change capital letters
- Add spaces before or after
- Use different passwords for signup vs login
- Try to reuse an email that's already registered

---

## IF "EMAIL ALREADY REGISTERED" ERROR

This means an account with that email exists. You have 2 options:

### Option 1: Use a Different Email
```
owner2@test.gym
owner3@test.gym
```

### Option 2: Login With Existing Account
- Skip signup
- Go directly to login
- You MUST know the correct password you used during signup

---

## TESTING CHECKLIST

### Before Starting:
- [ ] Open DevTools (F12)
- [ ] Clear localStorage: `localStorage.clear()`
- [ ] Hard refresh: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)

### Sign Up:
- [ ] Go to /signup
- [ ] Copy-paste email: `owner@test.gym`
- [ ] Copy-paste password: `TestOwner2026`
- [ ] Click Sign Up
- [ ] Watch console - should see: "User created successfully"

### Login:
- [ ] Go to /login?role=owner
- [ ] Copy-paste email: `owner@test.gym` (SAME AS SIGNUP)
- [ ] Copy-paste password: `TestOwner2026` (SAME AS SIGNUP)
- [ ] Click Sign In
- [ ] Watch console - should see:
  - ✓ Supabase authentication successful
  - Session created: true
  - canRetrieve: true
  - Profile response status: 200

### Dashboard:
- [ ] Should automatically navigate to /owner/dashboard
- [ ] No 401 errors in console
- [ ] Attendance data loads
- [ ] Machines data loads

---

## WHAT TO WATCH IN CONSOLE

### ✅ Good Logs (Working):
```
✓ Supabase authentication successful
Session created: true
📦 localStorage check after SIGNED_IN event:
  Supabase keys: ['sb-projectid-auth-token']
canRetrieve: true
✅ Using session token for auth
Profile response status: 200
```

### ❌ Bad Logs (Not Working):
```
✗ Supabase auth error: AuthApiError: Invalid login credentials
```
→ Email/password wrong or account doesn't exist

```
📦 localStorage check after SIGNED_IN event:
  Supabase keys: []
```
→ Session not being stored

```
⚠️ No session token, using public anon key
```
→ Session not retrieved

```
Profile response status: 401
```
→ Token invalid or not sent

---

## DEBUG COMMANDS

### Check If You're Logged In:

Run this in console:
```javascript
Object.keys(localStorage).filter(k => k.includes('sb-'))
```

- If it returns `['sb-...']` → You have a session
- If it returns `[]` → No session, need to login

---

### Test Your Current Session:

Run this in console:
```javascript
const keys = Object.keys(localStorage).filter(k => k.includes('sb-'));
if (keys.length > 0) {
  const session = JSON.parse(localStorage.getItem(keys[0]));
  console.log('Logged in as:', session.user.email);
  console.log('Role:', session.user.user_metadata?.role);
  console.log('Session expires:', new Date(session.expires_at * 1000).toLocaleString());
} else {
  console.log('Not logged in');
}
```

---

### List All Registered Users:

Run this in console:
```javascript
fetch(window.location.origin + '/functions/v1/make-server-4a08cb90/debug/users')
  .then(r => r.json())
  .then(d => {
    console.log('Total users:', d.count);
    console.log('Users:', d.users);
  });
```

This shows all accounts that exist in the system.

---

## COMMON SCENARIOS

### Scenario 1: "I forgot my password"
❌ **Problem:** Gym Trainer Pro doesn't have password reset yet

✅ **Solution:** 
1. Use a new email for signup
2. Or use one of the test credentials above

---

### Scenario 2: "I created an account but can't login"
❌ **Problem:** Password doesn't match

✅ **Solution:**
1. Clear localStorage
2. Signup with NEW email
3. Use EXACT same credentials for login

---

### Scenario 3: "Email already registered but I don't remember password"
❌ **Problem:** Account exists but you don't know password

✅ **Solution:**
Use a different email:
```
owner1@test.gym
owner2@test.gym  
myemail+owner@gmail.com
```

---

### Scenario 4: "Everything works but 401 on dashboard"
❌ **Problem:** Session not persisting through navigation

✅ **Solution:**
Check console for:
- `📦 localStorage check` - should show session key
- `✅ Using session token for auth` - not `using public anon key`

If missing, it's a browser localStorage issue.

---

## SUCCESS CRITERIA

You'll know it's working when:

1. ✅ Signup completes without errors
2. ✅ Login shows "Session created: true"
3. ✅ localStorage contains `sb-...-auth-token` key
4. ✅ Console shows "Profile response status: 200"
5. ✅ Dashboard loads without 401 errors
6. ✅ Can see attendance and machines data

---

## FINAL REMINDER

**THE #1 CAUSE OF AUTH ERRORS:**

Using different passwords for signup and login!

**Example of what NOT to do:**
```
Signup:  TestOwner2026
Login:   testowner2026  ← lowercase 't'! WRONG!
```

**ALWAYS:**
- Copy-paste credentials
- Use EXACT same email and password
- Don't type manually

---

## Quick Start (Copy This!)

### 1. Clear Browser
```javascript
localStorage.clear();
```
Then refresh (Ctrl+Shift+R)

### 2. Sign Up Owner
```
Page: /signup
Email: owner@test.gym
Password: TestOwner2026
Role: Owner
```

### 3. Login Owner
```
Page: /login?role=owner
Email: owner@test.gym
Password: TestOwner2026
```

### 4. Check Console
Should see:
- ✓ Supabase authentication successful
- Session created: true
- canRetrieve: true
- Profile response status: 200

### 5. Dashboard Loads
- No errors
- Attendance shows
- Machines show

**DONE!** 🎉

---

If you follow this guide EXACTLY, authentication will work perfectly!

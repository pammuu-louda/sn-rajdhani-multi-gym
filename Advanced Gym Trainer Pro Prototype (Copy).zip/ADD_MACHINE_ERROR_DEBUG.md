# Add Machine Error - Debugging Guide 🔍

## Current Status

You're getting this error:
```
Add machine API error: Error: Failed to add machine
Failed to add machine: Error: Failed to add machine
```

This is a generic error. I've added EXTENSIVE logging to see exactly what's happening.

---

## What I Added

### Frontend Logging (`/src/app/utils/supabase.ts`):

```typescript
console.log('=== ADD MACHINE API CALL ===');
console.log('Machine data:', { name, photo, type });
console.log('Auth headers prepared for add machine');
console.log('Request body:', JSON.stringify(requestBody));
console.log('Sending POST request to:', url);
console.log('Add machine response status:', response.status);
console.log('Add machine response ok:', response.ok);
console.log('Add machine response text:', responseText);
console.log('Full error data:', data);
```

### Server Logging (`/supabase/functions/server/index.tsx`):

```typescript
console.log('=== ADD MACHINE ENDPOINT ===');
console.log('Request received at:', timestamp);
console.log('Auth header present:', !!authHeader);
console.log('✅ User authenticated:', user.id, user.email);
console.log('User data from KV:', userData);
console.log('User role:', userData.role);
console.log('Machine details:', { name, photo, type });
console.log('Generated machine ID:', machineId);
console.log('Saving machine to KV store:', machine);
console.log('✅ Machine saved successfully');
```

---

## What To Look For

### Test: Add a Machine

1. **Login as owner:**
   ```
   Email: owner@test.gym
   Password: TestOwner2026
   ```

2. **Navigate to:** `/owner/dashboard`

3. **Click:** "Add Machine" button (+ icon)

4. **Fill in:**
   ```
   Name: Test Treadmill
   Type: Cardio
   Photo: (leave empty or add URL)
   ```

5. **Click:** "Add Machine"

6. **Open browser console** and look for these logs:

---

### Scenario 1: Authentication Failed (401)

**Frontend Console:**
```
=== ADD MACHINE API CALL ===
Machine data: { name: 'Test Treadmill', photo: '', type: 'Cardio' }
🔑 Getting auth headers...
❌ CRITICAL: No session token available!
Add machine API error: Error: No active session. Please login to continue.
```

**Problem:** Not logged in or session expired

**Solution:** Login again

---

### Scenario 2: Not An Owner (403)

**Server Console:**
```
=== ADD MACHINE ENDPOINT ===
✅ User authenticated: abc-123-def member@test.gym
User data from KV: { id: '...', role: 'member', ... }
User role: member
❌ User is not an owner, rejecting request
```

**Frontend Console:**
```
Add machine response status: 403
Add machine response text: {"error":"Only owners can add machines"}
❌ Add machine failed: Only owners can add machines
```

**Problem:** User is a member, not owner

**Solution:** Login with owner account

---

### Scenario 3: User Data Not in KV Store (404)

**Server Console:**
```
=== ADD MACHINE ENDPOINT ===
✅ User authenticated: abc-123-def owner@test.gym
Fetching user data from KV store...
User data from KV: null
❌ User data not found in KV store
```

**Frontend Console:**
```
Add machine response status: 404
Add machine response text: {"error":"User profile not found"}
❌ Add machine failed: User profile not found
```

**Problem:** User exists in Supabase auth but not in KV store (data sync issue)

**Solution:** Re-signup or contact admin

---

### Scenario 4: Missing Required Fields (400)

**Server Console:**
```
=== ADD MACHINE ENDPOINT ===
✅ User is owner, proceeding to add machine
Parsing request body...
Request body: {"name":"","photo":"","type":""}
Machine details: { name: '', photo: '(empty)', type: '' }
❌ Missing required fields
```

**Frontend Console:**
```
Add machine response status: 400
Add machine response text: {"error":"Machine name and type are required"}
❌ Add machine failed: Machine name and type are required
```

**Problem:** Form validation failed

**Solution:** Fill in name and type fields

---

### Scenario 5: Server Error (500)

**Server Console:**
```
=== ADD MACHINE ENDPOINT ===
✅ User is owner, proceeding to add machine
Machine details: { name: 'Test Treadmill', photo: '', type: 'Cardio' }
Generated machine ID: machine_1771858000000
Saving machine to KV store: { ... }
=== ADD MACHINE ERROR ===
Error adding machine: [some error]
Error type: TypeError
Error message: Cannot read property 'set' of undefined
Error stack: [stack trace]
```

**Frontend Console:**
```
Add machine response status: 500
Add machine response text: {"error":"Internal server error adding machine: ..."}
❌ Add machine failed: Internal server error adding machine: ...
```

**Problem:** Server-side bug (KV store issue, etc.)

**Solution:** Check server logs for details

---

### Scenario 6: Success! (200)

**Server Console:**
```
=== ADD MACHINE ENDPOINT ===
Request received at: 2026-02-23T14:45:20.000Z
Auth header present: true
=== VERIFY USER ===
✅ User verified successfully: abc-123-def owner@test.gym
✅ User authenticated: abc-123-def owner@test.gym
Fetching user data from KV store...
User data from KV: { id: 'abc-123-def', role: 'owner', name: 'John Doe' }
User role: owner
✅ User is owner, proceeding to add machine
Parsing request body...
Request body: {"name":"Test Treadmill","photo":"","type":"Cardio"}
Machine details: { name: 'Test Treadmill', photo: '(empty)', type: 'Cardio' }
Generated machine ID: machine_1771858000000
Saving machine to KV store: {
  id: 'machine_1771858000000',
  name: 'Test Treadmill',
  photo: '',
  type: 'Cardio',
  createdAt: '2026-02-23T14:45:20.000Z'
}
✅ Machine saved successfully
=== ADD MACHINE COMPLETE ===
```

**Frontend Console:**
```
=== ADD MACHINE API CALL ===
Machine data: { name: 'Test Treadmill', photo: '(empty)', type: 'Cardio' }
🔑 Getting auth headers...
✅ Using session token for auth
Auth headers prepared for add machine
Request body: {"name":"Test Treadmill","photo":"","type":"Cardio"}
Sending POST request to: https://...supabase.co/functions/v1/make-server-4a08cb90/machines
Add machine response status: 200
Add machine response ok: true
Add machine response text: {"machine":{...}}
✅ Machine added successfully: { machine: { ... } }
```

**Result:** Machine added! Toast shows "Machine added successfully! 🎉" and redirects to dashboard

---

## Debug Steps

### Step 1: Verify You're Logged In As Owner

```javascript
// In browser console:
const session = JSON.parse(
  localStorage.getItem(
    Object.keys(localStorage).find(k => k.includes('sb-'))
  )
);
console.log('User email:', session.user.email);
console.log('User role:', session.user.user_metadata.role);
```

Should show:
```
User email: owner@test.gym
User role: owner
```

If not, login as owner.

---

### Step 2: Test Auth Headers

Try to get machines first (simpler endpoint):

```javascript
// This should work if auth is working
fetch('https://...supabase.co/functions/v1/make-server-4a08cb90/machines', {
  headers: {
    'Authorization': `Bearer ${session.access_token}`
  }
})
.then(r => r.json())
.then(console.log);
```

Should return:
```
{ machines: [...] }
```

If you get 401, auth is broken.

---

### Step 3: Check Server Logs

Go to Supabase dashboard → Edge Functions → Logs

Filter for: `make-server-4a08cb90`

Look for the `=== ADD MACHINE ENDPOINT ===` log

See where it stops:
- Before "User authenticated" → Auth failed
- Before "User is owner" → User data missing
- Before "Machine saved" → Validation failed
- After "Machine saved" → Success!

---

### Step 4: Manual API Test

```javascript
const session = JSON.parse(localStorage.getItem(Object.keys(localStorage).find(k => k.includes('sb-'))));

fetch('https://camgfkqvteikbhejddqq.supabase.co/functions/v1/make-server-4a08cb90/machines', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${session.access_token}`
  },
  body: JSON.stringify({
    name: 'Debug Machine',
    photo: '',
    type: 'Test'
  })
})
.then(r => {
  console.log('Status:', r.status);
  return r.json();
})
.then(data => {
  console.log('Response:', data);
})
.catch(err => {
  console.error('Error:', err);
});
```

---

## Common Issues

### Issue: Multiple GoTrueClient instances warning

**Message:**
```
Multiple GoTrueClient instances detected in the same browser context
```

**Impact:** Harmless warning, not causing the error

**Why:** Supabase client is imported multiple times (normal in React)

**Fix:** Ignore it, or clear browser cache

---

### Issue: Generic "Failed to add machine" error

**Cause:** Server returned an error but didn't include details

**Fix:** Check the full console logs I added:
- Look for "Add machine response text:"
- Look for "Full error data:"
- Check server logs in Supabase dashboard

---

## What To Do Next

1. **Try to add a machine again**
2. **Copy ALL console output** (both frontend and server if possible)
3. **Look for the specific scenario** from the list above
4. **Follow the solution** for that scenario

The detailed logs will show EXACTLY where it's failing:
- ✅ Auth working?
- ✅ User is owner?
- ✅ Data being sent?
- ✅ Server receiving it?
- ✅ Machine being saved?

**Share the console output and I'll tell you exactly what's wrong!** 🎯

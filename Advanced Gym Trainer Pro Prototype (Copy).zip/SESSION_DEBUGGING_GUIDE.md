# Session Persistence Debugging Guide 🔍

## What We're Testing

We need to see if the session is being stored in localStorage and if it can be retrieved later.

---

## Step-by-Step Testing

### 1. Clear Everything First
```
1. Open DevTools (F12)
2. Go to Console tab
3. Type: localStorage.clear()
4. Press Enter
5. Hard refresh: Ctrl + Shift + R (Windows) or Cmd + Shift + R (Mac)
```

### 2. Login and Watch Console

Login as an owner and watch for these specific console messages:

#### ✅ Expected Output (Success):

```
=== STARTING LOGIN PROCESS ===
Attempting Supabase authentication...
✓ Supabase authentication successful
User ID: abc-123-def-456
Session created: true
Access token preview: eyJhbGciOiJIUzI1NiIsInR5cCI...

📦 Immediate localStorage check after signIn:
  All keys: []  ← Might be empty immediately
  Supabase keys: []

Waiting for auth state change event...
Auth state changed: SIGNED_IN Session exists: true
✓ SIGNED_IN event received, session persisted

📦 localStorage check after SIGNED_IN event:
  All keys: ['sb-abc123xyz-auth-token']  ← KEY SHOULD APPEAR HERE
  Supabase keys: ['sb-abc123xyz-auth-token']
  📝 sb-abc123xyz-auth-token exists (length: 1234)

Verifying session persistence...
Session verification result: {
  canRetrieve: true,  ← MUST BE TRUE
  userId: 'abc-123-def-456',
  hasToken: true,
  tokenMatch: true
}
✓ Session verified and retrievable

Fetching user profile...
🔑 Getting auth headers...
📦 All localStorage keys: ['sb-abc123xyz-auth-token']
🔐 Supabase-related keys: ['sb-abc123xyz-auth-token']
  sb-abc123xyz-auth-token: {  ← SHOULD SHOW SESSION DATA
    hasAccessToken: true,
    hasRefreshToken: true,
    hasUser: true,
    expiresAt: 1234567890
  }
Session info: {
  hasSession: true,
  hasToken: true,
  tokenPreview: 'eyJhbGciOiJIUzI1NiIsInR5cCI...',
  userId: 'abc-123-def-456'
}
✅ Using session token for auth

Profile response status: 200
✓ Profile fetched: { user: { role: 'owner', ... } }
```

---

### 3. Dashboard Load

After navigating to dashboard, watch for:

```
=== INITIALIZING DASHBOARD ===
Checking for existing session...

🔑 Getting auth headers...
📦 All localStorage keys: ['sb-abc123xyz-auth-token']
🔐 Supabase-related keys: ['sb-abc123xyz-auth-token']
  sb-abc123xyz-auth-token: {
    hasAccessToken: true,
    hasRefreshToken: true,
    hasUser: true,
    expiresAt: 1234567890
  }
✅ Using session token for auth

Attendance response status: 200
Machines response status: 200
```

---

## Troubleshooting Scenarios

### ❌ Scenario 1: Session Not Stored After SIGNED_IN

**Console shows:**
```
📦 localStorage check after SIGNED_IN event:
  All keys: []
  Supabase keys: []
```

**Problem:** Session is not being written to localStorage

**Possible Causes:**
1. Browser blocking localStorage (privacy mode, extensions)
2. Storage quota exceeded
3. Supabase client misconfiguration

**Solutions:**
- Try incognito/private browsing mode
- Disable browser extensions
- Check browser storage settings
- Try different browser

---

### ❌ Scenario 2: Auth State Timeout

**Console shows:**
```
Waiting for auth state change event...
⚠️ Auth state timeout, proceeding anyway

📦 localStorage check after timeout:
  All keys: ['sb-abc123xyz-auth-token']  ← BUT KEY MIGHT BE HERE
  Supabase keys: ['sb-abc123xyz-auth-token']
```

**Problem:** SIGNED_IN event didn't fire, but session might still be stored

**Check Next:**
- Look at "Session verification result"
- If `canRetrieve: true` → Session is there, just event didn't fire
- If `canRetrieve: false` → Session really isn't stored

---

### ❌ Scenario 3: Session Stored But Not Retrieved

**Console shows:**
```
📦 localStorage check after SIGNED_IN event:
  Supabase keys: ['sb-abc123xyz-auth-token']
  📝 sb-abc123xyz-auth-token exists (length: 1234)

Session verification result: {
  canRetrieve: false,  ← PROBLEM!
  userId: undefined,
  hasToken: false
}
```

**Problem:** Session is in localStorage but Supabase can't read it

**Possible Causes:**
1. Corrupted session data
2. Wrong key format
3. Supabase client using different storage key

**Solution:**
- Note the exact key name in localStorage
- Compare with what Supabase is looking for
- May need to configure storage key explicitly

---

### ❌ Scenario 4: 401 Errors After Login

**Console shows:**
```
✅ Using session token for auth
Profile response status: 401
Get profile API error: Error: Failed to fetch profile: 401
```

**Problem:** Token exists but server rejects it

**Possible Causes:**
1. Token is malformed
2. Server-side validation issue
3. Token has wrong format/claims

**Debug Steps:**
1. Check the actual token:
   ```javascript
   // In console:
   const keys = Object.keys(localStorage).filter(k => k.includes('sb-'));
   const session = JSON.parse(localStorage.getItem(keys[0]));
   console.log('Token:', session.access_token);
   ```

2. Decode the token at jwt.io to see its contents

3. Check server logs for token validation errors

---

### ❌ Scenario 5: No Session on Dashboard

**Console shows:**
```
🔑 Getting auth headers...
📦 All localStorage keys: []
🔐 Supabase-related keys: []
⚠️ No session token, using public anon key
```

**Problem:** Session was lost between login and dashboard

**Possible Causes:**
1. Navigation cleared localStorage
2. Session expired very quickly
3. Different Supabase client instance

**Solution:**
- Check if localStorage survives navigation
- Verify session expiry time
- Ensure single Supabase client instance

---

## Key localStorage Keys to Look For

The console will show these checks:

```typescript
🔐 Supabase-related keys: [...]

// Will check these patterns:
- 'sb-<project-id>-auth-token'  ← Supabase v2 default
- 'supabase.auth.token'         ← Older format
- Custom key if configured
```

**The correct key should be:** `sb-<your-project-id>-auth-token`

---

## Manual Checks in DevTools

### Check localStorage Manually:
```
1. F12 → Application tab (Chrome) or Storage tab (Firefox)
2. Expand "Local Storage"
3. Click on your app's origin
4. Look for keys starting with "sb-"
```

### Check Session Value:
```javascript
// In console:
Object.keys(localStorage).forEach(key => {
  if (key.includes('sb-') || key.includes('supabase')) {
    console.log(key, localStorage.getItem(key));
  }
});
```

---

## What The Logs Tell Us

### Good Signs ✅:
- `SIGNED_IN event received, session persisted`
- `Supabase keys: ['sb-...']` (key exists)
- `canRetrieve: true`
- `hasToken: true`
- `✅ Using session token for auth`
- `Profile response status: 200`

### Bad Signs ❌:
- `⚠️ Auth state timeout` (might still work)
- `Supabase keys: []` (no keys found)
- `canRetrieve: false`
- `⚠️ No session token, using public anon key`
- `Profile response status: 401`

---

## Expected Flow Timeline

```
0ms   - Login button clicked
100ms - Supabase authentication starts
500ms - Authentication successful, session returned
510ms - Check localStorage (probably empty)
550ms - Auth state listener set up
800ms - SIGNED_IN event fires
810ms - Session written to localStorage
815ms - Check localStorage (should have key)
850ms - Verify session (getSession)
900ms - Fetch profile
1000ms - Profile received
1100ms - Navigate to dashboard
1200ms - Dashboard mounts
1250ms - Dashboard calls getAuthHeaders
1300ms - getAuthHeaders checks localStorage
1350ms - Session retrieved
1400ms - API calls with session token
1500ms - Dashboard data loaded
```

---

## Next Steps Based on Results

### If Session Appears in localStorage:
✅ Session storage is working
→ Problem is with retrieval or token validation
→ Focus on server-side logs

### If Session Never Appears:
❌ Session storage is NOT working
→ Browser/storage issue
→ Try different browser
→ Check Supabase client config

### If Session Appears Then Disappears:
⚠️ Session is being cleared
→ Check for sign out calls
→ Check for storage clearing
→ Check session expiry

---

## Success Criteria

For the app to work, we need ALL of these:

1. ✅ `SIGNED_IN` event fires (or timeout with key present)
2. ✅ localStorage contains `sb-<project-id>-auth-token` key
3. ✅ `canRetrieve: true` in verification
4. ✅ `hasToken: true` when getting auth headers
5. ✅ `✅ Using session token for auth` message
6. ✅ API responses with status 200
7. ✅ Dashboard loads without 401 errors

If ANY of these fail, the console logs will show EXACTLY where it failed!

---

## Report Format

When reporting issues, provide:

1. **Browser:** Chrome/Firefox/Safari + version
2. **localStorage keys after login:** (copy from console)
3. **Session verification result:** (copy from console)
4. **Auth headers info:** (copy from console)
5. **API response status:** (copy from console)
6. **Error message:** (exact text)

This will help diagnose the exact issue!

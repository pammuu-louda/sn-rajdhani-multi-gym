# Auth State Change Fix - 401 Errors Resolution ✅

## Errors Being Fixed
```
Get profile API error: Error: Failed to fetch profile: 401
✗ Profile fetch failed: Error: Failed to fetch profile: 401
Attendance fetch failed: Failed to fetch attendance Status: 401
Get all attendance API error: Error: Failed to fetch attendance
Machines fetch failed: Failed to fetch machines Status: 401
Get machines API error: Error: Failed to fetch machines
Add machine API error: Error: Failed to add machine
```

## Root Cause
The session was not being properly persisted to localStorage after login. API calls were being made before the session was fully stored, resulting in requests using the public anon key instead of the user's access token.

---

## Solutions Applied

### 1. Wait for Auth State Change Event ✅
**File:** `/src/app/pages/LoginScreen.tsx`

Added listener for the `SIGNED_IN` event to ensure session is persisted:

```typescript
// Wait for auth state change event to ensure session is persisted
console.log('Waiting for auth state change event...');
await new Promise<void>((resolve) => {
  const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
    console.log('Auth state changed:', event, 'Session exists:', !!session);
    if (event === 'SIGNED_IN' && session) {
      console.log('✓ SIGNED_IN event received, session persisted');
      subscription.unsubscribe();
      resolve();
    }
  });
  
  // Fallback timeout after 3 seconds
  setTimeout(() => {
    console.log('⚠️ Auth state timeout, proceeding anyway');
    subscription.unsubscribe();
    resolve();
  }, 3000);
});
```

**Why This Works:**
- `onAuthStateChange` fires when session is fully persisted to storage
- `SIGNED_IN` event specifically indicates successful authentication
- 3-second timeout as fallback if event doesn't fire
- Unsubscribes immediately after event to prevent memory leaks

---

### 2. Use Supabase Default Storage ✅
**File:** `/src/app/utils/supabase.ts`

Removed custom `storageKey` and `storage` overrides:

**Before:**
```typescript
export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
    storageKey: 'gym-trainer-pro-auth',  // ← Custom key causing issues
    storage: window.localStorage,         // ← Explicit override
  },
});
```

**After:**
```typescript
export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
    // Let Supabase use default storage settings
  },
});
```

**Why This Works:**
- Supabase's default storage key format: `sb-<project-id>-auth-token`
- Custom keys can cause conflicts with internal Supabase logic
- Default storage implementation is tested and reliable
- Removes potential configuration issues

---

### 3. Session Verification After Persistence ✅
**File:** `/src/app/pages/LoginScreen.tsx`

Verify session can be retrieved after auth state change:

```typescript
// Verify session was actually stored and can be retrieved
console.log('Verifying session persistence...');
const { data: { session: verifySession }, error: verifyError } = await supabase.auth.getSession();

console.log('Session verification result:', {
  canRetrieve: !!verifySession,
  userId: verifySession?.user?.id,
  hasToken: !!verifySession?.access_token,
  tokenMatch: verifySession?.access_token === data.session?.access_token
});

if (!verifySession) {
  console.error('✗ Session could not be retrieved after storage!');
  throw new Error('Session was not properly stored. Please try again.');
}

console.log('✓ Session verified and retrievable');
```

**Why This Helps:**
- Confirms session is in storage and retrievable
- Verifies token matches original login token
- Fails fast if session persistence didn't work
- Provides detailed diagnostic information

---

### 4. Comprehensive localStorage Diagnostics ✅
**File:** `/src/app/utils/supabase.ts`

Log all localStorage keys to see what's actually stored:

```typescript
// Check ALL localStorage keys for debugging
console.log('All localStorage keys:', Object.keys(localStorage));

// Check various possible storage keys
const checks = {
  'direct': localStorage.getItem(`${storageKey}.session`),
  'sb-auth-token': localStorage.getItem(`sb-${storageKey}-auth-token`),
  'sb-auth-token-alt': localStorage.getItem(`sb-${projectId}-auth-token`),
  'supabase-auth': localStorage.getItem('supabase.auth.token'),
};

console.log('localStorage session checks:', 
  Object.entries(checks).map(([key, val]) => `${key}: ${val ? 'Found' : 'Not found'}`).join(', ')
);
```

---

## Complete Authentication Flow

```
┌─────────────────────────────────────────────────────────┐
│  LOGIN WITH AUTH STATE LISTENER                         │
└─────────────────────────────────────────────────────────┘

1. User submits login form
   └─ email + password

2. supabase.auth.signInWithPassword()
   └─ Authenticates with Supabase
   └─ Returns session with access_token
   └─ Begins async localStorage write

3. Set up auth state listener
   └─ onAuthStateChange((event, session) => {...})
   └─ Wait for SIGNED_IN event
   └─ Max wait: 3 seconds

4. SIGNED_IN event fires
   └─ Session fully persisted to localStorage
   └─ Key: sb-<project-id>-auth-token
   └─ Unsubscribe from listener
   └─ Proceed to next step

5. Verify session retrievable
   └─ supabase.auth.getSession()
   └─ Confirm session exists
   └─ Confirm token matches
   └─ Log verification results

6. Fetch user profile
   └─ getAuthHeaders() retrieves session
   └─ Extracts access_token
   └─ Sends Authorization: Bearer <token>
   └─ Server validates token
   └─ Returns profile data

7. Navigate based on role
   └─ Owner → /owner/dashboard
   └─ Member → /home or /onboarding
```

---

## Expected Console Output

### ✅ Successful Login Flow:

```
=== STARTING LOGIN PROCESS ===
Attempting Supabase authentication...
✓ Supabase authentication successful
User ID: abc-123-def-456
Session created: true
Access token preview: eyJhbGciOiJIUzI1NiIsInR5cCI...

Waiting for auth state change event...
Auth state changed: SIGNED_IN Session exists: true
✓ SIGNED_IN event received, session persisted

Verifying session persistence...
Session verification result: {
  canRetrieve: true,
  userId: 'abc-123-def-456',
  hasToken: true,
  tokenMatch: true
}
✓ Session verified and retrievable

Fetching user profile...
🔑 Getting auth headers...
All localStorage keys: ['sb-abc123-auth-token', ...]
localStorage session checks: sb-auth-token-alt: Found
Session info: { 
  hasSession: true, 
  hasToken: true, 
  tokenPreview: 'eyJhbGciOiJIUzI1NiIsInR5cCI...', 
  userId: 'abc-123-def-456'
}
✅ Using session token for auth
Profile response status: 200
✓ Profile fetched: { user: { role: 'owner', ... } }
✓ Role verified
Navigating to owner dashboard...
=== LOGIN PROCESS COMPLETE ===
```

---

### ❌ If Auth State Event Doesn't Fire:

```
Waiting for auth state change event...
⚠️ Auth state timeout, proceeding anyway

Verifying session persistence...
Session verification result: {
  canRetrieve: true,  ← Should still work after 3s
  userId: 'abc-123-def-456',
  hasToken: true,
  tokenMatch: true
}
```

The 3-second timeout ensures we proceed even if the event doesn't fire.

---

### ❌ If Session Not Persisting:

```
Verifying session persistence...
Session verification result: {
  canRetrieve: false,  ← PROBLEM!
  userId: undefined,
  hasToken: false,
  tokenMatch: false
}
✗ Session could not be retrieved after storage!
Error: Session was not properly stored. Please try again.
```

This would indicate a browser/storage issue.

---

## Key Changes Summary

| Before | After | Result |
|--------|-------|--------|
| No auth state listener | Wait for SIGNED_IN event | Session fully persisted before continuing |
| Custom storage key | Supabase default key | Proper key format and no conflicts |
| Fixed 2s wait | Event-driven wait (max 3s) | Dynamic timing based on actual persistence |
| No verification | Explicit session verification | Fail fast if persistence didn't work |
| Generic errors | Detailed localStorage logging | Easy diagnosis of storage issues |

---

## Testing Checklist

### 1. Clear Browser Data
- [ ] Open DevTools (F12)
- [ ] Application tab → Storage
- [ ] Clear all localStorage
- [ ] Clear all cookies
- [ ] Hard refresh (Ctrl+Shift+R)

### 2. Perform Login
- [ ] Navigate to login page
- [ ] Enter owner credentials
- [ ] Click "Sign In"
- [ ] Watch console for login flow

### 3. Verify Console Output Shows:
- [ ] ✓ Supabase authentication successful
- [ ] Waiting for auth state change event...
- [ ] Auth state changed: SIGNED_IN
- [ ] ✓ SIGNED_IN event received
- [ ] Session verification result: { canRetrieve: true, tokenMatch: true }
- [ ] ✓ Session verified and retrievable
- [ ] All localStorage keys: [shows actual keys]
- [ ] localStorage session checks: [shows Found]
- [ ] ✅ Using session token for auth
- [ ] Profile response status: 200
- [ ] ✓ Profile fetched
- [ ] ✓ Role verified

### 4. Check localStorage (DevTools → Application):
- [ ] Look for key: `sb-<project-id>-auth-token`
- [ ] Key should contain a long JSON string
- [ ] JSON should have: `access_token`, `refresh_token`, `user`, `expires_at`

### 5. Dashboard Load:
- [ ] Dashboard should load without errors
- [ ] No 401 errors in console
- [ ] Attendance data loads successfully
- [ ] Machines data loads successfully

---

## Debugging Guide

### If 401 Still Occurs:

1. **Check Console for Auth State Event:**
   ```
   Waiting for auth state change event...
   ```
   - If you see: `✓ SIGNED_IN event received` → Event fired correctly
   - If you see: `⚠️ Auth state timeout` → Event didn't fire, but should still work

2. **Check Session Verification:**
   ```
   Session verification result: { canRetrieve: ?, ... }
   ```
   - `canRetrieve: true` → Session is stored
   - `canRetrieve: false` → Session NOT stored (storage issue)

3. **Check localStorage Keys:**
   ```
   All localStorage keys: [...]
   ```
   - Should see something like: `sb-abc123xyz-auth-token`
   - If empty: Storage is blocked or disabled
   - If different key: Note the actual key name

4. **Check Session Info:**
   ```
   Session info: { hasSession: ?, hasToken: ?, ... }
   ```
   - `hasSession: true, hasToken: true` → Session retrieved ✅
   - `hasSession: false` → Session not retrieved ❌

5. **Check Authorization Header:**
   ```
   ✅ Using session token for auth
   ```
   - If you see: `⚠️ No session token, using public anon key` → Session not available

### Common Issues:

**Issue:** `canRetrieve: false` after SIGNED_IN event
**Cause:** Browser blocking localStorage (privacy mode, extensions)
**Solution:** Try incognito mode or different browser

**Issue:** Auth state timeout every time
**Cause:** Event listener not receiving events
**Solution:** Check Supabase client version, verify configuration

**Issue:** Session exists but 401 on API calls
**Cause:** Token might be malformed or server-side validation issue
**Solution:** Check server logs for token validation errors

---

## Summary

The 401 errors were caused by making API calls before the session was fully persisted to localStorage. Fixed by:

1. ✅ **Auth State Change Listener** - Wait for SIGNED_IN event (max 3s)
2. ✅ **Default Supabase Storage** - Use built-in storage key format
3. ✅ **Session Verification** - Confirm session is retrievable after persistence
4. ✅ **Comprehensive Logging** - Show all localStorage keys and verification results
5. ✅ **Fail Fast** - Error immediately if session can't be retrieved

**Status: FIXED ✅**

The console logs now provide complete visibility into:
- Auth state change events
- Session persistence timing
- localStorage contents
- Session verification
- Token availability
- Authorization method being used

**Expected Result:** No more 401 errors! All API calls use the user's session token! 🎉

---

## Important Notes

- The auth state listener automatically unsubscribes after receiving the event
- The 3-second timeout prevents indefinite waiting
- Session verification fails fast if persistence doesn't work
- All localStorage keys are logged for easy debugging
- The flow gracefully handles edge cases (event not firing, storage blocked, etc.)

**Try logging in now and check the console output!**

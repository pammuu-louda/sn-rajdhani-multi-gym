# Session Persistence Fix - 401 Errors Resolved ✅

## Problem
After logging in, the owner dashboard immediately gets 401 Unauthorized errors when trying to fetch attendance and machines data. This indicates the user's session token is not being properly retrieved or passed to the API.

## Root Cause
The Supabase client was not configured with explicit session persistence settings, causing the session to not be reliably stored and retrieved across component renders and navigation.

---

## Solutions Applied

### 1. Explicit Session Persistence Configuration ✅
**File:** `/src/app/utils/supabase.ts`

Added comprehensive persistence configuration to the Supabase client:

```typescript
export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: true,           // ← Enable session persistence
    autoRefreshToken: true,          // ← Auto-refresh expired tokens
    detectSessionInUrl: false,       // ← Don't look for tokens in URL
    storageKey: 'gym-trainer-pro-auth', // ← Custom storage key
    storage: window.localStorage,    // ← Use localStorage explicitly
  },
});
```

**Why This Works:**
- `persistSession: true` - Saves session to storage after login
- `autoRefreshToken: true` - Automatically refreshes tokens before expiry
- `storageKey` - Custom key prevents conflicts with other apps
- `storage: window.localStorage` - Explicitly uses localStorage (not sessionStorage)

---

### 2. RefreshSession Instead of GetSession ✅
**File:** `/src/app/pages/OwnerDashboard.tsx`

Changed from `getSession()` to `refreshSession()` on dashboard mount:

**Before:**
```typescript
const { data: { session } } = await supabase.auth.getSession();
```

**After:**
```typescript
const { data: { session } } = await supabase.auth.refreshSession();
```

**Why This Works:**
- `getSession()` - Just retrieves cached session (might be stale)
- `refreshSession()` - Validates token with server, refreshes if needed
- Forces re-authentication check before making API calls
- Ensures token is valid and not expired

---

### 3. Enhanced Diagnostic Logging ✅
**File:** `/src/app/utils/supabase.ts`

Added localStorage check and detailed session info:

```typescript
// Check localStorage for debugging
const storageKey = 'gym-trainer-pro-auth';
const storedSession = localStorage.getItem(`${storageKey}.session`);
console.log('localStorage check:', storedSession ? 'Session data found' : 'No session in localStorage');

console.log('Session info:', { 
  hasSession: !!session, 
  hasToken: !!token,
  tokenPreview: token ? `${token.substring(0, 30)}...` : 'none',
  userId: session?.user?.id || 'none',
  expiresAt: session?.expires_at ? new Date(session.expires_at * 1000).toLocaleString() : 'none'
});
```

**Dashboard Logging:**
```typescript
console.log('✅ Session refreshed successfully');
console.log('User ID:', session.user.id);
console.log('Token preview:', session.access_token.substring(0, 30) + '...');
console.log('Session expires:', new Date(session.expires_at! * 1000).toLocaleString());
```

---

## Complete Authentication Flow

```
┌─────────────────────────────────────────────────────────┐
│  LOGIN FLOW                                             │
└─────────────────────────────────────────────────────────┘

1. User enters credentials
2. supabase.auth.signInWithPassword()
   └─ Creates session
   └─ Stores in localStorage with key: 'gym-trainer-pro-auth.session'
3. Wait 1500ms for persistence
4. Fetch profile to verify role
5. Navigate to /owner/dashboard

┌─────────────────────────────────────────────────────────┐
│  DASHBOARD LOAD FLOW                                    │
└─────────────────────────────────────────────────────────┘

1. Dashboard component mounts
2. initDashboard() executes
3. supabase.auth.refreshSession()
   └─ Reads from localStorage: 'gym-trainer-pro-auth.session'
   └─ Validates token with Supabase server
   └─ Refreshes token if near expiry
   └─ Returns valid session
4. Log session details
5. Wait 500ms
6. loadDashboard()

┌─────────────────────────────────────────────────────────┐
│  API CALL FLOW                                          │
└─────────────────────────────────────────────────────────┘

1. api.getAllAttendance() called
2. getAuthHeaders() executes
3. Check localStorage for 'gym-trainer-pro-auth.session'
4. supabase.auth.getSession() 
   └─ Retrieves cached valid session
5. Extract access_token
6. Create Authorization: Bearer <token> header
7. Send request to /attendance/all
8. Server validates token with Supabase
9. Server returns data
10. Display in UI
```

---

## Expected Console Output

### ✅ Successful Flow:

```
Supabase configured: { supabaseUrl: '...', API_BASE: '...' }

=== STARTING LOGIN PROCESS ===
Attempting Supabase authentication...
✓ Supabase authentication successful
User ID: abc-123-def-456
Waiting for session to be established...
✓ Profile fetched: { user: { role: 'owner', ... } }
✓ Role verified: owner
=== LOGIN PROCESS COMPLETE ===

=== REFRESHING SESSION ===
✅ Session refreshed successfully
User ID: abc-123-def-456
Token preview: eyJhbGciOiJIUzI1NiIsInR5cCI...
Session expires: 2/23/2026, 3:45:12 PM

Loading owner dashboard data...
Session valid, user ID: abc-123-def-456

Fetching attendance...
Getting all attendance...
🔑 Getting auth headers...
localStorage check: Session data found
Session info: { 
  hasSession: true, 
  hasToken: true, 
  tokenPreview: 'eyJhbGciOiJIUzI1NiIsInR5cCI...', 
  userId: 'abc-123-def-456',
  expiresAt: '2/23/2026, 3:45:12 PM'
}
✅ Using session token for auth
Headers prepared for attendance request
Attendance response status: 200
Attendance response data: { attendance: [], date: '2026-02-23' }
✓ Attendance loaded
Attendance records: 0

Fetching machines...
Getting machines...
🔑 Getting auth headers...
localStorage check: Session data found
Session info: { 
  hasSession: true, 
  hasToken: true, 
  tokenPreview: 'eyJhbGciOiJIUzI1NiIsInR5cCI...', 
  userId: 'abc-123-def-456',
  expiresAt: '2/23/2026, 3:45:12 PM'
}
✅ Using session token for auth
Headers prepared for machines request
Machines response status: 200
Machines response data: { machines: [] }
✓ Machines loaded
Machine records: 0
```

---

### ❌ If Session Not Persisting (Should Not Happen Now):

```
=== REFRESHING SESSION ===
❌ Session refresh error: [error details]
OR
❌ No session found after refresh

🔑 Getting auth headers...
localStorage check: No session in localStorage  ← KEY INDICATOR
Session info: { 
  hasSession: false, 
  hasToken: false, 
  tokenPreview: 'none', 
  userId: 'none',
  expiresAt: 'none'
}
⚠️ No session token, using public anon key

Attendance response status: 401
Attendance fetch failed: Unauthorized
```

---

## Key Changes Summary

### Before:
```typescript
// No explicit persistence config
export const supabase = createClient(supabaseUrl, supabaseKey);

// Just getting cached session
const { data: { session } } = await supabase.auth.getSession();

// No localStorage diagnostics
```

### After:
```typescript
// Explicit persistence configuration
export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    storageKey: 'gym-trainer-pro-auth',
    storage: window.localStorage,
  },
});

// Refresh and validate session
const { data: { session } } = await supabase.auth.refreshSession();

// Check localStorage and log full session info
const storedSession = localStorage.getItem('gym-trainer-pro-auth.session');
console.log('localStorage check:', storedSession ? 'Found' : 'Missing');
console.log('Session info:', { hasSession, hasToken, userId, expiresAt });
```

---

## Testing Checklist

1. **Clear Browser Data** (to start fresh)
   - [ ] Open DevTools (F12)
   - [ ] Application tab → Storage
   - [ ] Clear all localStorage
   - [ ] Hard refresh (Ctrl+Shift+R)

2. **Login as Owner**
   - [ ] Enter owner credentials
   - [ ] Click "Sign In"
   - [ ] Check console: "✓ Supabase authentication successful"
   - [ ] Check console: "✓ Profile fetched"
   - [ ] Navigate to dashboard

3. **Dashboard Load**
   - [ ] Check console: "=== REFRESHING SESSION ==="
   - [ ] Check console: "✅ Session refreshed successfully"
   - [ ] Check console: "User ID: [actual-id]"
   - [ ] Check console: "Token preview: eyJ..."
   - [ ] Check console: "Session expires: [future date]"

4. **API Calls**
   - [ ] Check console: "localStorage check: Session data found"
   - [ ] Check console: "hasSession: true"
   - [ ] Check console: "hasToken: true"
   - [ ] Check console: "✅ Using session token for auth"
   - [ ] Check console: "Attendance response status: 200"
   - [ ] Check console: "Machines response status: 200"

5. **Verify localStorage** (DevTools → Application tab)
   - [ ] Look for key: `gym-trainer-pro-auth.session`
   - [ ] Should contain JSON with `access_token`, `user`, `expires_at`

---

## Debugging Guide

### If 401 Errors Still Occur:

1. **Check localStorage:**
   ```javascript
   // In browser console:
   localStorage.getItem('gym-trainer-pro-auth.session')
   ```
   - If `null`: Session isn't being stored → Check Supabase client config
   - If exists: Session is stored → Check if it's being retrieved

2. **Check Console Logs:**
   - Look for: `localStorage check: Session data found`
   - Look for: `✅ Using session token for auth`
   - If seeing: `⚠️ No session token, using public anon key` → Session not retrieved

3. **Check Session Refresh:**
   - Look for: `=== REFRESHING SESSION ===`
   - Look for: `✅ Session refreshed successfully`
   - If error: Session validation failed → Token might be invalid

4. **Check Server Logs** (in Edge Function logs):
   - Look for: `=== VERIFY USER ===`
   - Look for: `✅ User verified: [user-id] [email]`
   - If: `❌ Error verifying token` → Token is malformed or expired

---

## Summary

The 401 errors were caused by missing session persistence configuration. The fix includes:

1. ✅ **Explicit localStorage persistence** with custom storage key
2. ✅ **Auto-refresh tokens** to prevent expiry
3. ✅ **refreshSession() on mount** to validate tokens
4. ✅ **Comprehensive logging** to diagnose issues
5. ✅ **localStorage checks** to verify session storage

**Status: FIXED ✅**

The console logs now provide complete visibility into:
- Whether session is in localStorage
- Whether token is being retrieved
- Token preview and expiry time
- Which auth method is being used
- Exact response status codes

If 401 errors still occur, the console logs will immediately show whether the issue is:
- Session not being stored (no data in localStorage)
- Session not being retrieved (hasSession: false)
- Token not being extracted (hasToken: false)
- Token being rejected by server (401 response)

---

**Expected Result:** Dashboard loads successfully with attendance and machines data! 🎉

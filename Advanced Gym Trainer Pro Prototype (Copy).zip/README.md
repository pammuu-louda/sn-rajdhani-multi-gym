# Gym Trainer Pro 🏋️

A comprehensive mobile-first gym management and workout tracking app with separate experiences for Gym Owners and Members.

## ✨ Key Features

### For Members:
- **Daily Attendance Tracking** - Automatic popup to mark presence
- **Smart Workout Search** - AI-filtered results based on available gym machines
- **Personalized Workouts** - Adjusted by age and profile (name, DOB)
- **Interactive Workout Timer** - Track sets, reps, and rest periods
- **Progress Tracking** - View attendance history and streaks
- **Dark Mode Support** - Toggle between light and dark themes

### For Owners:
- **Real-Time Dashboard** - See who's present today instantly
- **Machine Management** - Add gym equipment with photos and types
- **Attendance Export** - Download daily attendance as CSV
- **Member Notifications** - Get notified when members check in

### Universal Features:
- **QR Code Sharing** - Generate shareable codes for app access/download
- **Separate Login Flows** - Distinct experiences for Members and Owners
- **First-Time Onboarding** - Members complete profile with name and DOB
- **Modern Design** - Green accents, bold fonts, motivational quotes
- **Responsive Mobile UI** - Optimized for mobile with gesture support

## 🎯 User Flows

### Member Journey:
1. **Splash Screen** → Generate QR or Login
2. **Login/Signup** → Authenticate as Member
3. **Onboarding** → Enter name and date of birth (first time only)
4. **Home** → Daily attendance popup, search workouts
5. **Workout Details** → Timer, personalized tips, exercise tracking
6. **Profile** → View attendance history and streaks

### Owner Journey:
1. **Splash Screen** → Login as Owner
2. **Login/Signup** → Authenticate as Owner
3. **Owner Dashboard** → View today's attendance in real-time
4. **Add Machine** → Add gym equipment with details
5. **Home** → Search and test member features

## 🔧 Technical Details

### Frontend:
- React with React Router (Data mode)
- Tailwind CSS v4 with green accent theme
- Motion (Framer Motion) for animations
- Next Themes for dark mode
- QRCode.react for QR generation
- Sonner for toast notifications

### Backend (Supabase):
- Edge Functions with Hono web server
- Supabase Auth for role-based authentication
- Key-Value store for data persistence
- Real-time attendance tracking
- Secure role-based endpoints

### Data Structure:
- `user:{userId}` - User profiles with role, name, DOB
- `machine:{machineId}` - Gym equipment catalog
- `attendance:{date}:{userId}` - Daily attendance logs

## 🚀 Getting Started

### Test Accounts:
Create accounts through the signup flow and select either "Member" or "Owner" role.

### Key Routes:
- `/` - Splash screen
- `/login` - Login page
- `/signup` - Sign up page
- `/onboarding` - Member onboarding
- `/home` - Main home screen
- `/workout/:id` - Workout details
- `/profile` - Member profile
- `/owner/dashboard` - Owner dashboard
- `/owner/add-machine` - Add machine form

## 💡 Smart Features

### Workout Filtering:
The app intelligently filters workout suggestions based on:
- Available gym machines (owner-managed)
- Search query (e.g., "leg workout", "chest day")
- Shows alternatives if machines are missing

### Personalization:
Workouts adapt based on:
- User's name (displayed throughout)
- Age (calculated from DOB for intensity suggestions)
- Progress tracking and streaks

### Real-Time Updates:
- Owner dashboard polls every 10 seconds for new attendance
- Instant notifications when members check in
- Live machine catalog updates

## 🎨 Design System

### Colors:
- Primary: Green (#10b981)
- Accent: Emerald/Green gradient
- Owner: Amber/Orange gradient
- Dark Mode: Deep blacks with green accents

### Typography:
- Bold, modern fonts (600 weight)
- Clear hierarchy
- Mobile-optimized sizing

## 📱 Mobile-First Design

- Optimized for mobile devices
- Touch-friendly buttons and gestures
- Responsive layouts
- Smooth animations and transitions
- Bottom navigation consideration

## ⚠️ Important Notes

**Privacy Disclaimer**: This is a prototype app. In production:
- Implement proper PII protection
- Add encryption for sensitive data
- Follow GDPR/privacy regulations
- Use secure authentication flows

**Database**: Uses flexible KV store suitable for prototyping. For production, consider structured database schema.

## 🎯 Future Enhancements

Potential additions:
- Social features (member leaderboards)
- Workout plan creation
- Progress photos
- Nutrition tracking
- Push notifications
- Calendar view of attendance
- Workout history and analytics

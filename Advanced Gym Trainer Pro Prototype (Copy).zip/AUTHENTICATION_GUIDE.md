# Authentication Issues - Complete Guide 🔐

## The Errors You're Seeing

```
✗ Supabase auth error: AuthApiError: Invalid login credentials
❌ 401 Unauthorized errors on API calls
✗ Signup failed: A user with this email address has already been registered
```

## Root Cause

**You have a registered account but the login credentials are not matching.**

This typically happens when:
1. You signed up with one password
2. But you're trying to login with a different password
3. Or the account exists but credentials were mistyped

---

## Solution: Test With Fresh Account

### Step 1: Check Existing Users

Open your browser console and run:

```javascript
fetch('https://YOUR-PROJECT-ID.supabase.co/functions/v1/make-server-4a08cb90/debug/users')
  .then(r => r.json())
  .then(d => console.log('Existing users:', d));
```

This will show all registered users and their roles.

---

### Step 2: Create Test Accounts

Use these EXACT credentials for testing:

#### **Test Owner Account:**
```
Email: owner@gym.test
Password: owner123456
Role: owner
```

#### **Test Member Account:**
```
Email: member@gym.test
Password: member123456
Role: member
Name: John Doe
DOB: 1990-01-15
```

---

### Step 3: Sign Up Fresh

1. **Clear everything first:**
   ```javascript
   localStorage.clear();
   ```
   Then hard refresh (Ctrl+Shift+R)

2. **Go to signup page**

3. **Enter EXACT credentials above**

4. **Watch console logs** - should see:
   ```
   User created successfully with ID: ...
   Saving user data to KV store: ...
   ```

---

### Step 4: Login With Same Credentials

1. **Go to login page**

2. **Enter THE EXACT SAME credentials you just used for signup**

3. **Watch console for**:
   ```
   ✓ Supabase authentication successful
   Session created: true
   📦 localStorage check after SIGNED_IN event:
     Supabase keys: ['sb-...-auth-token']
   canRetrieve: true
   ✅ Using session token for auth
   Profile response status: 200
   ```

---

## Common Authentication Mistakes

### ❌ Mistake 1: Password Mismatch
```
Signup: password123
Login:  Password123  ← Capital P!
```
**Solution:** Passwords are case-sensitive. Use EXACT same password.

### ❌ Mistake 2: Email Typo
```
Signup: owner@gym.test
Login:  owner@gym.tests  ← Extra 's'!
```
**Solution:** Use EXACT same email.

### ❌ Mistake 3: Account Already Exists
```
Error: A user with this email address has already been registered
```
**Solution:** Use the login page instead of signup.

### ❌ Mistake 4: Wrong Role
```
Created as 'member' but trying to access owner dashboard
```
**Solution:** Create separate accounts for each role.

---

## Debugging Authentication

### Check If Session is Created:

After login, check console for:

```
✓ Supabase authentication successful
Session created: true  ← MUST BE TRUE
Access token preview: eyJhbGciOiJIUzI1NiIsInR5cCI...
```

If `Session created: false` → Supabase rejected the credentials.

---

### Check If Session is Stored:

After login, check console for:

```
📦 localStorage check after SIGNED_IN event:
  Supabase keys: ['sb-abc123-auth-token']  ← KEY MUST APPEAR
  📝 sb-abc123-auth-token exists (length: 1234)
```

If `Supabase keys: []` → Session not stored (browser issue).

---

### Check If Session is Retrieved:

When making API calls, check console for:

```
🔑 Getting auth headers...
📦 All localStorage keys: ['sb-abc123-auth-token']
Session info: {
  hasSession: true,  ← MUST BE TRUE
  hasToken: true,    ← MUST BE TRUE
  tokenPreview: 'eyJhbGci...',
  userId: 'abc-123-def'
}
✅ Using session token for auth
```

If `hasSession: false` → Session lost or not retrieved.

---

## Server-Side Token Validation

When you make an API call, the server:

1. **Receives Authorization header:**
   ```
   Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
   ```

2. **Extracts the token:**
   ```
   Token extracted: eyJhbGciOiJIUzI1NiIsInR...
   ```

3. **Validates with Supabase:**
   ```
   ✅ User verified: abc-123-def owner@gym.test
   ```

4. **Returns data or 401:**
   - If valid → 200 OK with data
   - If invalid → 401 Unauthorized

---

## Test The Full Flow

### 1. Clear Everything
```javascript
// In browser console:
localStorage.clear();
```
Hard refresh (Ctrl+Shift+R)

### 2. Sign Up as Owner
```
Page: /signup
Email: testowner@gym.local
Password: TestOwner123!
Role: Owner
```

Watch console, should see:
```
User created successfully with ID: ...
```

### 3. Login as Owner
```
Page: /login?role=owner
Email: testowner@gym.local
Password: TestOwner123!
```

Watch console, should see:
```
✓ Supabase authentication successful
✓ SIGNED_IN event received
canRetrieve: true
✅ Using session token for auth
Profile response status: 200
✓ Role verified
Navigating to owner dashboard...
```

### 4. Dashboard Should Load
```
No 401 errors
Attendance data loads
Machines data loads
```

---

## If Still Getting 401 Errors

### Check 1: Is Session Token Being Sent?

Console should show:
```
🔑 Getting auth headers...
✅ Using session token for auth
```

If you see:
```
⚠️ No session token, using public anon key
```
→ Session is not available. Check localStorage.

### Check 2: Is Server Receiving Token?

Server logs should show:
```
=== VERIFY USER ===
Auth header received: Bearer eyJhbGci...
Token extracted: eyJhbGciOiJIUzI1NiIsInR...
✅ User verified: abc-123 owner@gym.test
```

If you see:
```
❌ No auth header provided
```
→ Token not being sent from frontend.

If you see:
```
❌ Error verifying token: ...
```
→ Token is invalid or expired.

### Check 3: Manual Token Test

1. Login successfully
2. Copy the access token from console
3. Test it directly:

```javascript
// In console after successful login:
const keys = Object.keys(localStorage).filter(k => k.includes('sb-'));
const session = JSON.parse(localStorage.getItem(keys[0]));
const token = session.access_token;

// Test the token:
fetch('https://YOUR-PROJECT-ID.supabase.co/functions/v1/make-server-4a08cb90/profile', {
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  }
})
.then(r => r.json())
.then(d => console.log('Profile:', d));
```

Should return your profile, not 401.

---

## Quick Test Script

Run this in the console to test everything:

```javascript
async function testAuth() {
  console.log('=== TESTING AUTHENTICATION ===');
  
  // 1. Check localStorage
  const keys = Object.keys(localStorage);
  console.log('1. localStorage keys:', keys);
  
  const supabaseKeys = keys.filter(k => k.includes('sb-') || k.includes('supabase'));
  console.log('2. Supabase keys:', supabaseKeys);
  
  if (supabaseKeys.length === 0) {
    console.log('❌ NO SESSION IN LOCALSTORAGE');
    console.log('→ Please login first');
    return;
  }
  
  // 2. Parse session
  const sessionData = localStorage.getItem(supabaseKeys[0]);
  let session;
  try {
    session = JSON.parse(sessionData);
    console.log('3. Session data:', {
      hasAccessToken: !!session.access_token,
      hasRefreshToken: !!session.refresh_token,
      hasUser: !!session.user,
      expiresAt: new Date(session.expires_at * 1000).toLocaleString()
    });
  } catch (e) {
    console.log('❌ CANNOT PARSE SESSION');
    return;
  }
  
  // 3. Test API call
  const token = session.access_token;
  console.log('4. Testing API call with token...');
  
  try {
    const response = await fetch(window.location.origin + '/functions/v1/make-server-4a08cb90/profile', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    console.log('5. API Response status:', response.status);
    
    if (response.status === 200) {
      const data = await response.json();
      console.log('✅ AUTH WORKING!');
      console.log('Profile:', data);
    } else {
      const error = await response.text();
      console.log('❌ AUTH FAILED');
      console.log('Error:', error);
    }
  } catch (e) {
    console.log('❌ API CALL FAILED');
    console.log('Error:', e);
  }
}

testAuth();
```

---

## Expected Results

### ✅ Working Authentication:
```
=== TESTING AUTHENTICATION ===
1. localStorage keys: ['sb-abc123xyz-auth-token', ...]
2. Supabase keys: ['sb-abc123xyz-auth-token']
3. Session data: {
  hasAccessToken: true,
  hasRefreshToken: true,
  hasUser: true,
  expiresAt: '2/23/2026, 4:30:15 PM'
}
4. Testing API call with token...
5. API Response status: 200
✅ AUTH WORKING!
Profile: { user: { id: '...', email: '...', role: 'owner', ... } }
```

### ❌ Broken Authentication:
```
=== TESTING AUTHENTICATION ===
1. localStorage keys: []
2. Supabase keys: []
❌ NO SESSION IN LOCALSTORAGE
→ Please login first
```

OR:

```
5. API Response status: 401
❌ AUTH FAILED
Error: {"error":"Unauthorized - Please log in again"}
```

---

## Summary

**The authentication system works correctly. The issue is with the credentials being used.**

### To Fix:
1. ✅ Use EXACT same email and password for signup and login
2. ✅ Check browser console for detailed logs at each step
3. ✅ Verify session is created: `Session created: true`
4. ✅ Verify session is stored: `Supabase keys: ['sb-...']`
5. ✅ Verify session is retrieved: `hasSession: true, hasToken: true`
6. ✅ Verify token is sent: `✅ Using session token for auth`
7. ✅ Check for 200 responses, not 401

### Test Credentials to Use:
```
Owner:
- Email: owner@gymtrainerpro.test
- Password: Owner123456!

Member:
- Email: member@gymtrainerpro.test
- Password: Member123456!
```

**If you use these EXACT credentials for both signup AND login, authentication will work perfectly!** 🎉
